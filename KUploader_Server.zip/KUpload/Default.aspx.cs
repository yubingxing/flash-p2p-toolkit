﻿//
//
// By kingnare.com 2008.12.12
//
//
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Text;
using System.Security.Cryptography;

namespace KUpload
{
    public partial class _Default : System.Web.UI.Page
    {
        /// <summary>
        /// 数据块的信息字节长度,默认为32位的整型,即4个字节
        /// </summary>
        private uint headerLen = 4;
        private string serverPath = System.Web.HttpContext.Current.Server.MapPath(".") + @"\files\";

        protected void Page_Load(object sender, EventArgs e)
        {
            
            try
            {
                //Flash传来的数据流
                Stream reader = Request.InputStream;

                //头信息长度,Flash传递过来的默认为32位整型
                byte[] header = new byte[headerLen];
                for (int pos = 0; pos < headerLen; pos++)
                {
                    reader.Read(header, header.Length - 1 - pos, 1);
                }
                int len = BitConverter.ToInt32(header, 0);

                //根据头信息长度,读取数据流信息描述字串
                byte[] info = new byte[1024];
                reader.Read(info, 0, len);
                string msg = System.Text.Encoding.UTF8.GetString(info, 0, len);

                string[] sArray = msg.Split('_');
                string fn;
                int begin = 0;
                int length = 0;
                string sign = sArray[0];

                if (!String.IsNullOrEmpty(sign))
                {
                    switch (sign)
                    {
                        //开始信息处理
                        case "b":
                            length = Int32.Parse(sArray[1]);
                            string suffix = sArray[2];
                            int nums = Int32.Parse(sArray[3]);
                            fn = sArray[4];
                            SaveLog(serverPath + fn + "." + suffix + ".log", "b\t" + length.ToString() + "\t" + suffix.ToString() + "\t" + fn + "\t" + nums + "\t" + fn + "#");
                            Response.Write(fn + "." + suffix);
                            break;
                        //数据块处理
                        case "p":
                            msg = sArray[1];
                            begin = Int32.Parse(sArray[2]);
                            length = Int32.Parse(sArray[3]);
                            fn = sArray[4];
                            SavePart(reader, serverPath + fn, begin, len);
                            //SaveLog(serverPath + fn + ".log", "p\t" + msg + "\t" + begin.ToString() + "\t" + length.ToString() + "\t#");
                            SaveLog(serverPath + fn + ".log", "p\t" + msg + "\t#");
                            break;
                        //结束信息处理
                        case "e":
                            fn = sArray[1];
                            length = Int32.Parse(sArray[2]);
                            string re;
                            if (!File.Exists(serverPath + fn + ".log"))
                            {
                                re = "-1";
                            }
                            else
                            {
                                //比较日志数据,如果全部上传成功,返回1,否则返回未成功的数据
                                re = CheckLog(serverPath + fn + ".log");
                            }
                            Response.Write(re);
                            break;
                        default:
                            break;
                    }

                }
            }
            catch(Exception err)
            {
                SaveErrorLog(serverPath + "error.log", err);
            }
            finally
            {
                Response.End();
            }
        }

        /// <summary>
        /// 检查日志文件,若返回序列长度大于0,则返回给Flash缺失的块
        /// 若序列长度等于0,返回给Flash字串"1"
        /// 未编写出错处理,应与前台Flash做好出错处理规则
        /// </summary>
        /// <param name="logpath">日志文件路径</param>
        /// <returns>"1"或将重传的序列</returns>
        private string CheckLog(string logpath)
        {
            StreamReader sr = new StreamReader(logpath, System.Text.Encoding.UTF8);
            int num = 0;
            ArrayList indexs = new ArrayList();
            
            string content = sr.ReadToEnd();
            string[] contentArray = content.Split(new char[] { '#'});
            for (uint index = 0; index < contentArray.Length; index++)
            {
                string line = contentArray[index];
                if(!String.IsNullOrEmpty(line))
                {
                    string[] records = line.Split((char)9);
                    if (records[0] == "p")
                    {
                        indexs.Add(Int32.Parse(records[1]));
                    }
                    if (records[0] == "b")
                    {
                        num = Int32.Parse(records[4]);
                    }
                }
            }

            //如果长度大于0,查找未成功序号,如果小于或等于0,则返回SWF,令其重传文件
            ArrayList result = new ArrayList();
            if (indexs.Count > 0)
            {
                indexs.Sort();
                
                if (indexs.Count > 0 && num > 0)
                {
                    int tmpIndex = 0;
                    int tmpCell = 0;
                    while (tmpIndex < indexs.Count)
                    {
                        if (indexs[tmpIndex] != null)
                        {
                            if (tmpCell == (int)indexs[tmpIndex])
                            {
                                tmpIndex++;
                                tmpCell++;

                            }
                            else if (tmpCell < (int)indexs[tmpIndex])
                            {
                                result.Add(tmpCell);
                                tmpCell++;
                            }
                            else if (tmpCell > (int)indexs[tmpIndex])
                            {
                                tmpIndex++;
                            }
                        }
                    }
                }
                if (indexs.Count > 0 && (int)indexs[indexs.Count - 1] < num - 1)
                {
                    for (int i = (int)indexs[indexs.Count - 1]; i < num; i++)
                    {
                        result.Add(i);
                    }
                }
            }
            else
            {
                for (int i = 0; i < num; i++)
                {
                    result.Add(i);
                }
            }

            sr.Close();

            if (result.Count > 0)
            {
                StringBuilder sb = new StringBuilder();
                for (int j = 0; j < result.Count; j++)
                {
                    if (j == 0)
                    {
                        sb.Append(result[0].ToString());
                    }
                    else
                    {
                        sb.Append("," + result[j].ToString());
                    }
                }
                return sb.ToString();
            }
            else
            {
                //删除日志文件并返回"1"
                SaveLog(logpath, "e\t#");
                if (File.Exists(logpath))
                {
                    File.Delete(logpath);
                }
                return "1";
            }
        }

        /// <summary>
        /// 保存数据块到文件
        /// </summary>
        /// <param name="reader">数据流</param>
        /// <param name="filepath">文件路径</param>
        /// <param name="begin">数据流位置</param>
        /// <param name="headerLength">头信息长度</param>
        private void SavePart(Stream reader, string filepath, int begin, int headerLength)
        {
            byte[] buff = new byte[1024];
            reader.Seek(headerLen + headerLength, SeekOrigin.Begin);
            int c = 0;
            using (FileStream fs = new FileStream(filepath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
            {
                fs.Seek(begin, SeekOrigin.Begin);
                while ((c = reader.Read(buff, 0, buff.Length)) > 0)
                {
                    fs.Write(buff, 0, c);
                }
                fs.Close(); 
            }
        }

        /// <summary>
        /// 保存数据块相关信息
        /// </summary>
        /// <param name="logpath"></param>
        /// <param name="msg"></param>
        private void SaveLog(string logpath, string msg)
        {
            using (FileStream log = new FileStream(logpath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
            {
                byte[] logBytes = Encoding.UTF8.GetBytes(msg);
                log.Seek(0, SeekOrigin.End);
                log.Write(logBytes, 0, logBytes.Length);
                log.Close();
            }
        }

        /// <summary>
        /// 保存异常信息到日志文件
        /// </summary>
        /// <param name="path"></param>
        /// <param name="e"></param>
        private void SaveErrorLog(string path, Exception e)
        {
            using(FileStream log = new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
            {
                byte[] logBytes = Encoding.UTF8.GetBytes(e.ToString());
                log.Seek(0, SeekOrigin.End);
                log.Write(logBytes, 0, logBytes.Length);
                log.Close();
            }
        }
    }
}
